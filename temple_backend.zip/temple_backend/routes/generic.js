const express = require('express');
const pool = require('../db');
const { requireAuth, requireWriteAccess, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Maps the store name the frontend already uses (IndexedDB-style, camelCase)
// to the actual PostgreSQL table name, plus which extra columns (besides
// "data") that table pulls out for fast querying / uniqueness.
const STORE_MAP = {
  settings:            { table: 'settings',            fixedId: true },
  funds:                { table: 'funds' },
  incomeCategories:     { table: 'income_categories' },
  expenseCategories:    { table: 'expense_categories' },
  bankAccounts:         { table: 'bank_accounts' },
  receipts:             { table: 'receipts',            extra: ['date','amount','receiptNo:receipt_no'], unique: 'receipt_no', uniqueField: 'receiptNo' },
  payments:              { table: 'payments',            extra: ['date','amount','voucherNo:voucher_no'], unique: 'voucher_no', uniqueField: 'voucherNo' },
  transfers:             { table: 'transfers',            extra: ['date','amount'] },
  loans:                 { table: 'loans',                extra: ['date'] },
  chittyMembers:         { table: 'chitty_members' },
  chittyCollections:     { table: 'chitty_collections',   extra: ['date','amountReceived:amount'] },
  chittyPayouts:         { table: 'chitty_payouts',       extra: ['date','amount'] },
  journal:                { table: 'journal',              raw: true } // journal rows are proper columns, not JSONB — handled separately below
};

function badStore(res, store) {
  res.status(404).json({ error: `Unknown store: ${store}` });
}

async function logAudit(req, storeName, action, recordId, oldValue, newValue, reason) {
  try {
    await pool.query(
      'INSERT INTO audit_logs (username, store_name, action, record_id, old_value, new_value, reason) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [req.user ? req.user.username : null, storeName, action, recordId, oldValue ? JSON.stringify(oldValue) : null, newValue ? JSON.stringify(newValue) : null, reason || null]
    );
  } catch (e) { console.error('Audit log failed', e); }
}

function extraColumns(cfg, data) {
  const cols = [], vals = [];
  (cfg.extra || []).forEach(spec => {
    const [srcField, colNameRaw] = spec.includes(':') ? spec.split(':') : [spec, spec];
    const colName = colNameRaw; // e.g. amount
    cols.push(colName);
    vals.push(data[srcField] != null ? data[srcField] : null);
  });
  return { cols, vals };
}

// ---------- JOURNAL (special: real columns, no JSONB) ----------
router.get('/journal', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM journal ORDER BY date, id');
  res.json(rows.map(r => ({
    id: r.id, groupId: r.group_id, date: r.date, account: r.account, side: r.side,
    amount: parseFloat(r.amount), fund: r.fund, description: r.description,
    sourceType: r.source_type, sourceId: r.source_id, isReversal: r.is_reversal, createdAt: r.created_at
  })));
});
router.post('/journal', requireAuth, requireWriteAccess, async (req, res) => {
  const j = req.body;
  const { rows } = await pool.query(
    `INSERT INTO journal (group_id, date, account, side, amount, fund, description, source_type, source_id, is_reversal)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [j.groupId, j.date, j.account, j.side, j.amount, j.fund || null, j.description || null, j.sourceType || null, j.sourceId || null, !!j.isReversal]
  );
  res.json({ id: rows[0].id, ...j });
});

// ---------- GENERIC JSONB STORES ----------
router.get('/:store', requireAuth, async (req, res) => {
  const cfg = STORE_MAP[req.params.store];
  if (!cfg || cfg.raw) return badStore(res, req.params.store);
  const { rows } = await pool.query(`SELECT id, data FROM ${cfg.table} ORDER BY id`);
  res.json(rows.map(r => ({ id: r.id, ...r.data })));
});

router.get('/:store/:id', requireAuth, async (req, res) => {
  const cfg = STORE_MAP[req.params.store];
  if (!cfg || cfg.raw) return badStore(res, req.params.store);
  const { rows } = await pool.query(`SELECT id, data FROM ${cfg.table} WHERE id = $1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json({ id: rows[0].id, ...rows[0].data });
});

router.post('/:store', requireAuth, requireWriteAccess, async (req, res) => {
  const store = req.params.store;
  const cfg = STORE_MAP[store];
  if (!cfg || cfg.raw) return badStore(res, store);
  const data = { ...req.body };
  delete data.id;
  const { cols, vals } = extraColumns(cfg, data);

  try {
    let sql, params;
    if (cfg.fixedId) {
      // settings-style: single row, id always 1, upsert
      sql = `INSERT INTO ${cfg.table} (id, data) VALUES (1, $1)
             ON CONFLICT (id) DO UPDATE SET data = $1, updated_at = now() RETURNING id, data`;
      params = [JSON.stringify(data)];
    } else {
      const colNames = ['data', 'created_by', ...cols];
      const placeholders = colNames.map((_, i) => `$${i + 1}`);
      params = [JSON.stringify(data), req.user.id, ...vals];
      sql = `INSERT INTO ${cfg.table} (${colNames.join(',')}) VALUES (${placeholders.join(',')}) RETURNING id, data`;
    }
    const { rows } = await pool.query(sql, params);
    await logAudit(req, store, 'create', rows[0].id, null, rows[0].data);
    res.json({ id: rows[0].id, ...rows[0].data });
  } catch (e) {
    if (e.code === '23505') {
      return res.status(409).json({ error: `Duplicate value — ${cfg.uniqueField || 'this record'} must be unique.` });
    }
    console.error(e);
    res.status(500).json({ error: 'Could not save this record. Please try again.' });
  }
});

router.put('/:store/:id', requireAuth, requireWriteAccess, async (req, res) => {
  const store = req.params.store;
  const cfg = STORE_MAP[store];
  if (!cfg || cfg.raw) return badStore(res, store);
  const id = req.params.id;
  const data = { ...req.body };
  delete data.id;
  const { cols, vals } = extraColumns(cfg, data);

  const { rows: oldRows } = await pool.query(`SELECT data FROM ${cfg.table} WHERE id = $1`, [id]);
  const oldValue = oldRows[0] ? oldRows[0].data : null;
  if (!oldValue && !cfg.fixedId) return res.status(404).json({ error: 'Record not found.' });

  try {
    const setClauses = ['data = $1'].concat(cols.map((c, i) => `${c} = $${i + 2}`));
    const params = [JSON.stringify(data), ...vals, id];
    const sql = `UPDATE ${cfg.table} SET ${setClauses.join(', ')} WHERE id = $${params.length} RETURNING id, data`;
    const { rows } = await pool.query(sql, params);
    if (!rows[0]) return res.status(404).json({ error: 'Record not found.' });
    const action = data.voided ? 'void' : 'update';
    await logAudit(req, store, action, id, oldValue, rows[0].data, data.voidReason);
    res.json({ id: rows[0].id, ...rows[0].data });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not update this record. Please try again.' });
  }
});

module.exports = router;
