const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Same store list the frontend already knows about (camelCase names),
// mapped to real table names.
const TABLES = {
  settings: 'settings', funds: 'funds', incomeCategories: 'income_categories',
  expenseCategories: 'expense_categories', bankAccounts: 'bank_accounts',
  receipts: 'receipts', payments: 'payments', transfers: 'transfers', loans: 'loans',
  chittyMembers: 'chitty_members', chittyCollections: 'chitty_collections', chittyPayouts: 'chitty_payouts'
};

// Which extra (non-JSONB) columns each table keeps, mirroring routes/generic.js —
// duplicated here since this file also inserts rows directly during restore/import.
const EXTRA_COLS = {
  receipts: [['date','date'], ['amount','amount'], ['receiptNo','receipt_no']],
  payments: [['date','date'], ['amount','amount'], ['voucherNo','voucher_no']],
  transfers: [['date','date'], ['amount','amount']],
  loans: [['date','date']],
  chittyCollections: [['date','date'], ['amountReceived','amount']],
  chittyPayouts: [['date','date'], ['amount','amount']]
};
function buildInsert(store, table, rest) {
  const spec = EXTRA_COLS[store] || [];
  const cols = ['data', ...spec.map(([, col]) => col)];
  const vals = [JSON.stringify(rest), ...spec.map(([field]) => (rest[field] != null ? rest[field] : null))];
  const placeholders = vals.map((_, i) => `$${i + 1}`);
  return { sql: `INSERT INTO ${table} (${cols.join(',')}) VALUES (${placeholders.join(',')})`, vals };
}

async function dumpAll() {
  const dump = {};
  for (const [store, table] of Object.entries(TABLES)) {
    const { rows } = await pool.query(`SELECT id, data FROM ${table} ORDER BY id`);
    dump[store] = rows.map(r => ({ id: r.id, ...r.data }));
  }
  const { rows: journalRows } = await pool.query('SELECT * FROM journal ORDER BY id');
  dump.journal = journalRows.map(r => ({
    id: r.id, groupId: r.group_id, date: r.date, account: r.account, side: r.side,
    amount: parseFloat(r.amount), fund: r.fund, description: r.description,
    sourceType: r.source_type, sourceId: r.source_id, isReversal: r.is_reversal
  }));
  return dump;
}

// Full JSON backup, downloadable — this is the permanent, off-device copy.
router.get('/', requireAuth, async (req, res) => {
  const dump = await dumpAll();
  const counts = Object.fromEntries(Object.entries(dump).map(([k, v]) => [k, v.length]));
  await pool.query('INSERT INTO backup_records (filename, taken_by, row_counts) VALUES ($1,$2,$3)',
    [`Temple_Accounts_Backup_${new Date().toISOString().slice(0,10)}.json`, req.user.username, JSON.stringify(counts)]);
  res.setHeader('Content-Disposition', `attachment; filename="Temple_Accounts_Backup_${new Date().toISOString().slice(0,10)}.json"`);
  res.json(dump);
});

// Preview a backup/export file before restoring or importing — never act blind.
router.post('/preview', requireAuth, requireAdmin, async (req, res) => {
  const data = req.body || {};
  const summary = {};
  for (const store of Object.keys(TABLES)) summary[store] = Array.isArray(data[store]) ? data[store].length : 0;
  const totalIncome = (data.receipts || []).filter(r => !r.voided).reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);
  const totalExpense = (data.payments || []).filter(p => !p.voided).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
  res.json({ summary, totalIncome, totalExpense, memberCount: (data.chittyMembers || []).length, fundCount: (data.funds || []).length });
});

// REPLACES all current data — admin only, requires explicit confirm flag.
router.post('/restore', requireAuth, requireAdmin, async (req, res) => {
  const { data, confirm } = req.body || {};
  if (!confirm) return res.status(400).json({ error: 'Restore must be explicitly confirmed.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const table of Object.values(TABLES)) await client.query(`TRUNCATE ${table} RESTART IDENTITY CASCADE`);
    await client.query('TRUNCATE journal RESTART IDENTITY');
    for (const [store, table] of Object.entries(TABLES)) {
      for (const rec of data[store] || []) {
        const { id, ...rest } = rec;
        if (store === 'settings') {
          await client.query('INSERT INTO settings (id, data) VALUES (1,$1)', [JSON.stringify(rest)]);
        } else {
          const { sql, vals } = buildInsert(store, table, rest);
          await client.query(sql, vals);
        }
      }
    }
    for (const j of data.journal || []) {
      await client.query(
        `INSERT INTO journal (group_id, date, account, side, amount, fund, description, source_type, source_id, is_reversal)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [j.groupId, j.date, j.account, j.side, j.amount, j.fund || null, j.description || null, j.sourceType || null, j.sourceId || null, !!j.isReversal]
      );
    }
    await client.query('COMMIT');
    await pool.query('INSERT INTO audit_logs (username, store_name, action, reason) VALUES ($1,$2,$3,$4)',
      [req.user.username, 'ALL', 'restore', 'Full restore from uploaded backup']);
    res.json({ ok: true });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).json({ error: 'Restore failed — no data was changed.' });
  } finally {
    client.release();
  }
});

// MERGES an old export in (e.g. the previous IndexedDB-only app's backup
// file) — skips receipts/payments whose receipt/voucher number already
// exists, so re-running an import never creates duplicates.
router.post('/migrate', requireAuth, requireAdmin, async (req, res) => {
  const { data, confirm } = req.body || {};
  if (!confirm) return res.status(400).json({ error: 'Import must be explicitly confirmed.' });
  const result = { imported: {}, skippedDuplicates: {} };
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const [store, table] of Object.entries(TABLES)) {
      if (store === 'settings') continue; // don't overwrite live settings during a merge import
      let imported = 0, skipped = 0;
      for (const rec of data[store] || []) {
        const { id, ...rest } = rec;
        try {
          const { sql, vals } = buildInsert(store, table, rest);
          await client.query(sql, vals);
          imported++;
        } catch (e) {
          if (e.code === '23505') skipped++; else throw e;
        }
      }
      result.imported[store] = imported;
      result.skippedDuplicates[store] = skipped;
    }
    await client.query('COMMIT');
    await pool.query('INSERT INTO audit_logs (username, store_name, action, reason, new_value) VALUES ($1,$2,$3,$4,$5)',
      [req.user.username, 'ALL', 'import', 'Merged import from uploaded file', JSON.stringify(result)]);
    res.json(result);
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).json({ error: 'Import failed — no data was changed.' });
  } finally {
    client.release();
  }
});

module.exports = router;
