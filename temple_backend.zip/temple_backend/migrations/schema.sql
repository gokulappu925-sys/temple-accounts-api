-- ============================================================
-- Temple Accounting & Fund Management — PostgreSQL schema
-- Generic "store" tables mirror the old IndexedDB object stores,
-- so the existing frontend logic needs almost no rewriting.
-- Each row's actual fields live in a JSONB "data" column; a few
-- columns are pulled out separately purely to make indexing and
-- server-side reporting fast.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------- USERS & AUTH ----------
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','treasurer','viewer')),
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login TIMESTAMPTZ
);

-- ---------- GENERIC DATA STORES ----------
-- One table per "collection". id is the internal transaction id
-- (never the receipt/voucher number). date/amount are pulled out
-- as real columns for fast reports; everything else lives in data.
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY,
  data JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS funds (
  id SERIAL PRIMARY KEY,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS income_categories (
  id SERIAL PRIMARY KEY,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expense_categories (
  id SERIAL PRIMARY KEY,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bank_accounts (
  id SERIAL PRIMARY KEY,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS receipts (
  id SERIAL PRIMARY KEY,
  receipt_no TEXT UNIQUE,
  date DATE,
  amount NUMERIC(14,2),
  voided BOOLEAN NOT NULL DEFAULT false,
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_receipts_date ON receipts(date);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  voucher_no TEXT UNIQUE,
  date DATE,
  amount NUMERIC(14,2),
  voided BOOLEAN NOT NULL DEFAULT false,
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(date);

CREATE TABLE IF NOT EXISTS transfers (
  id SERIAL PRIMARY KEY,
  date DATE,
  amount NUMERIC(14,2),
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS loans (
  id SERIAL PRIMARY KEY,
  date DATE,
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chitty_members (
  id SERIAL PRIMARY KEY,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chitty_collections (
  id SERIAL PRIMARY KEY,
  date DATE,
  amount NUMERIC(14,2),
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chitty_payouts (
  id SERIAL PRIMARY KEY,
  date DATE,
  amount NUMERIC(14,2),
  data JSONB NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Double-entry journal: every receipt/payment/transfer/loan/chitty
-- movement posts a balanced debit+credit pair here. This is the
-- permanent source of truth for the Ledger and Trial Balance.
CREATE TABLE IF NOT EXISTS journal (
  id SERIAL PRIMARY KEY,
  group_id TEXT NOT NULL,
  date DATE NOT NULL,
  account TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('debit','credit')),
  amount NUMERIC(14,2) NOT NULL,
  fund TEXT,
  description TEXT,
  source_type TEXT,
  source_id INTEGER,
  is_reversal BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_journal_account ON journal(account);
CREATE INDEX IF NOT EXISTS idx_journal_date ON journal(date);
CREATE INDEX IF NOT EXISTS idx_journal_source ON journal(source_type, source_id);

-- ---------- AUDIT TRAIL ----------
CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  username TEXT,
  store_name TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('create','update','void','restore','import')),
  record_id INTEGER,
  old_value JSONB,
  new_value JSONB,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- BACKUP RECORDS ----------
CREATE TABLE IF NOT EXISTS backup_records (
  id SERIAL PRIMARY KEY,
  filename TEXT NOT NULL,
  taken_by TEXT,
  row_counts JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
