const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Not logged in.' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, username, role }
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
}

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only an administrator can do this.' });
  }
  next();
}

// Treasurer and admin can write accounting entries; viewer cannot.
function requireWriteAccess(req, res, next) {
  if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'treasurer')) {
    return res.status(403).json({ error: 'You do not have permission to make changes.' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin, requireWriteAccess };
